import './App.css'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

function App() {

  const {
      data,dataUpdatedAt,error,errorUpdatedAt,
      failureCount,failureReason,fetchStatus,isError,
      isFetched,isFetchedAfterMount,isFetching,isInitialLoading,
      isLoading,isLoadingError,isPaused,isPending,
      isPlaceholderData,isRefetchError,isRefetching,isStale,
      isSuccess,isEnabled,promise,refetch,status,
  } = useQuery({
    queryKey: ['repoData'],
    queryFn: () =>
      fetch('https://api.restful-api.dev/objects').then((res) =>
        res.json(),
      ),
  })

  console.log({data,dataUpdatedAt,error,errorUpdatedAt,
      failureCount,failureReason,fetchStatus,isError,
      isFetched,isFetchedAfterMount,isFetching,isInitialLoading,
      isLoading,isLoadingError,isPaused,isPending,
      isPlaceholderData,isRefetchError,isRefetching,isStale,
      isSuccess,isEnabled,promise,refetch,status,})
  if (data) {
    console.log("data : ", data)
  }
  if (isPending) return 'Loading...'
  if (error) return 'An error has occurred: ' + error.message


  return (
    <>
      Hello
    </>
  )
}

export default App
